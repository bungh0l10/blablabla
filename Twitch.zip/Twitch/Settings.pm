package Plugins::Twitch::Settings;

use strict;
use Digest::MD5 qw(md5_hex);

use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $log   = logger('plugin.twitch');
my $prefs = preferences('plugin.twitch');

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_TWITCH');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/twitch/settings/basic.html');
}

1;
