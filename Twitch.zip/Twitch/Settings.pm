package Plugins::Twitch::Settings;

use strict;
use warnings;

use Digest::MD5 qw(md5_hex);
use base qw(Slim::Web::Settings);

use HTTP::Status qw(RC_MOVED_TEMPORARILY);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Web::HTTP;

my $log   = logger('plugin.twitch');
my $prefs = preferences('plugin.twitch');

sub new {
	my $class = shift;
	my $self = $class->SUPER::new;
	return $self;
}

sub name {
	return Slim::Web::HTTP::CSRF->protectName('PLUGIN_TWITCH');
}

sub page {
	return Slim::Web::HTTP::CSRF->protectURI('plugins/twitch/settings/basic.html');
}

sub handler {
	my ($class, $client, $paramRef) = @_;

	if ($paramRef->{'saveSettings'}) {
		if (defined $paramRef->{'pref_oauth_token'}) {
			my $token = $paramRef->{'pref_oauth_token'};
			$prefs->set('oauth_token', $token);
			$log->info("Token gespeichert: $token");
		}
	}

	$paramRef->{'pref_oauth_token'} = $prefs->get('oauth_token');

	return $class->SUPER::handler($client, $paramRef);
}

1;
