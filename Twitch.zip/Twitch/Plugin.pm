package Plugins::Twitch::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Control::Request;
use Slim::Utils::Strings qw(string cstring);

use JSON::XS::VersionOneAndTwo qw(encode_json decode_json);

my $log = Slim::Utils::Log->addLogCategory({
    category     => 'plugin.twitch',
    defaultLevel => 'DEBUG',
    description  => 'PLUGIN_TWITCH',
    logGroups    => 'SCANNER',
});

my $prefs = preferences('plugin.twitch');

sub initPlugin {
    my ($class, $client) = @_;

    $class->SUPER::initPlugin(
        feed    => \&getFeedItems,
        tag     => 'twitch',
        menu    => 'radios',
        is_app  => 1,
        weight  => 1,
    );

    if (main::WEBUI) {
        require Plugins::Twitch::Settings;
        Plugins::Twitch::Settings->new();
    }

    $log->debug("Twitch Audio Stream Plugin initialized.");
}

sub getDisplayName {
    return 'PLUGIN_TWITCH';
}

sub getFeedItems {
    my ($client, $callback, $args) = @_;

    if (!$args->{search}) {
        return $callback->([{
            name => cstring($client, 'PLUGIN_TWITCH_SEARCH'),
            type => 'search',
            url  => \&getFeedItems,
        }]);
    }

    my $query = $args->{search};
    searchTwitch($client, $query, $callback);
}

sub searchTwitch {
    my ($client, $query, $callback) = @_;

    my $clientId = 'kimne78kx3ncx6brgo4mv6wki5h1ko';
    my $oauth    = $prefs->get('token') || '';

    my $payload = encode_json({
        query => 'query SearchChannels($query: String!) {
            searchChannels(query: $query, first: 10) {
              edges {
                item {
                  displayName
                  login
                  profileImageURL(width: 300)
                  stream {
                    title
                    id
                  }
                }
              }
            }
        }',
        variables => { query => $query }
    });

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;
            my $data = eval { decode_json($json) };
            my @items;

            for my $edge (@{ $data->{data}->{searchChannels}->{edges} || [] }) {
                my $item = $edge->{item};
                next unless $item->{login};

                push @items, {
                    name => $item->{displayName} . ($item->{stream} ? " - " . $item->{stream}->{title} : ''),
                    url  => sub { playStream($client, $item->{login}, $item->{profileImageURL}, $item->{stream}->{title}) },
                    icon => $item->{profileImageURL},
                    type => 'link',
                };
            }

            $callback->(\@items);
        },
        sub {
            $log->warn("Fehler bei Twitch-Suche: $_[0]");
            $callback->([{
                name => "Fehler beim Laden",
                type => 'text',
            }]);
        },
        { timeout => 10 }
    );

    $http->headers({
        'Client-ID'    => $clientId,
        'Authorization' => "OAuth $oauth",
        'Content-Type' => 'application/json',
        'User-Agent'   => 'Mozilla/5.0',
    });

    $http->post('https://gql.twitch.tv/gql', $payload);
}

sub playStream {
    my ($client, $channel, $image, $title) = @_;

    my $token_req = {
        operationName => 'PlaybackAccessToken_Template',
        variables     => {
            login      => $channel,
            playerType => 'embed',
        },
        query => 'query PlaybackAccessToken_Template($login: String!, $playerType: String!) { streamPlaybackAccessToken(channelName: $login, params: { platform: "web", playerBackend: "mediaplayer", playerType: $playerType }) { signature value } }',
    };

    my $token_json = encode_json($token_req);

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;
            my $data = eval { decode_json($json) };
            return unless $data;

            my $sig = $data->{data}->{streamPlaybackAccessToken}->{signature};
            my $tok = $data->{data}->{streamPlaybackAccessToken}->{value};

            my $m3u8 = "https://usher.ttvnw.net/api/channel/hls/${channel}.m3u8?sig=${sig}&token=${tok}&allow_audio_only=true";

            my $m3u8_http = Slim::Networking::SimpleAsyncHTTP->new(
                sub {
                    my $body = shift;
                    my ($audio_url) = $body =~ /(https.*audio_only.*\.m3u8)/;
                    return unless $audio_url;

                    $client->playingSong->pluginData(wmaMeta => {
                        icon   => $image,
                        cover  => $image,
                        artist => $channel,
                        title  => $title || 'Live Twitch Stream',
                    });

                    Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
                    Slim::Control::Request::executeRequest($client, ['playlist', 'play', $audio_url]);
                },
                sub { $log->warn("Fehler beim Laden des M3U8: $_[0]") }
            );

            $m3u8_http->get($m3u8);
        },
        sub { $log->warn("Token-Fehler: $_[0]") }
    );

    $http->headers({
    'User-Agent'    => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
    'Accept'        => '*/*',
    'Origin'        => 'https://www.twitch.tv',
    'Referer'       => 'https://www.twitch.tv/',
    'Content-Type'  => 'application/json',
    'Client-ID'     => 'kimne78kx3ncx6brgo4mv6wki5h1ko',
    'Authorization' => 'OAuth ' . $prefs->get('token'),
});


    $http->post('https://gql.twitch.tv/gql', $token_json);
}

1;
