package Plugins::Twitch::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Control::Request;
use Slim::Utils::Strings qw(string cstring);

use JSON::XS::VersionOneAndTwo qw(encode_json decode_json);

my $log   = Slim::Utils::Log->addLogCategory({
    category     => 'plugin.twitch',
    defaultLevel => 'DEBUG',
    description  => 'PLUGIN_TWITCH',
    logGroups    => 'SCANNER',
});

my $prefs = preferences('plugin.twitch');

sub initPlugin {
    my ($class, $client) = @_;

    $class->SUPER::initPlugin(
        feed    => \&getFeedItems,
        tag     => 'twitch',
        menu    => 'radios',
        is_app  => 1,
        weight  => 1,
    );

    if (main::WEBUI) {
        require Plugins::Twitch::Settings;
        Plugins::Twitch::Settings->new();
    }

    $log->debug("Twitch Plugin initialized.");
}

sub getDisplayName {
    return 'PLUGIN_TWITCH';
}

sub getFeedItems {
    my ($client, $callback, $args) = @_;

    if (!$args->{search}) {
        return $callback->([{
            name => cstring($client, 'PLUGIN_TWITCH_SEARCH'),
            type => 'search',
            url  => \&getFeedItems,
        }]);
    }

    my $query = $args->{search};
    searchTwitch($client, $query, $callback);
}

sub searchTwitch {
    my ($client, $query, $callback) = @_;

    my $clientId = 'kimne78kx3ncx6brgo4mv6wki5h1ko';
    my $oauth    = $prefs->get('oauth_token') || '';

    my $payload = encode_json([{
        operationName => 'SearchResultsPage_SearchResults',
        variables => {
            query => $query,
            options => {
                type  => 'CHANNEL',
                first => 10,
            }
        },
        extensions => {
            persistedQuery => {
                version     => 1,
                sha256Hash  => '8b3c96d2f4fd1a2aa7a2c3fc46a3a86b2f6d58c9efcb21f75d87ee6e85f1e4ba',
            }
        }
    }]);

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;

            my $data = eval { decode_json($json) };
            if ($@ || !$data || ref($data) ne 'ARRAY' || !$data->[0]{data}) {
                $log->warn("Ungültige JSON-Antwort von Twitch. JSON: $json");
                return $callback->([{
                    name => "Fehlerhafte Antwort von Twitch",
                    type => 'text',
                }]);
            }

            my $edges = $data->[0]{data}{search}{edges};
            unless ($edges && ref($edges) eq 'ARRAY') {
                $log->warn("Keine Suchergebnisse erhalten. Antwort: $json");
                return $callback->([{
                    name => "Keine Kanäle gefunden",
                    type => 'text',
                }]);
            }

            my @items;
            foreach my $edge (@$edges) {
                my $item = $edge->{item};
                next unless $item->{__typename} eq 'Channel';

                my $login     = $item->{login};
                my $title     = $item->{displayName};
                my $image     = $item->{profileImageURL};
                my $isLive    = $item->{isLive};
                my $streamTitle = $isLive ? ($item->{broadcastSettings}->{title} || 'Live Stream') : '';

                push @items, {
                    name => $title . ($isLive ? " - $streamTitle" : ''),
                    icon => $image,
                    type => 'link',
                    url  => "play:twitch:$login",
                };
            }

            $log->debug("Twitch-Suche erfolgreich: $query - " . scalar(@items) . " Einträge");
            $callback->(\@items);
        },
        sub {
            my ($http, $error) = @_;
            my $response = $http->response();
            my $status   = $response->code;
            my $msg      = $response->message;
            my $content  = $http->content;

            $log->warn("Fehler bei Twitch-Suche:");
            $log->warn("Statuscode: $status");
            $log->warn("Fehlermeldung: $msg");
            $log->warn("Antwortinhalt: $content");
            $log->warn("Suchbegriff: $query");

            $callback->([{
                name => "Fehler beim Abrufen von Twitch-Daten (HTTP $status)",
                type => 'text',
            }]);
        },
        { timeout => 10 }
    );

    $http->headers({
        'User-Agent'    => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        'Accept'        => '*/*',
        'Origin'        => 'https://www.twitch.tv',
        'Referer'       => 'https://www.twitch.tv/',
        'Content-Type'  => 'application/json',
        'Client-ID'     => $clientId,
        'Authorization' => "OAuth $oauth",
    });

    $http->post('https://gql.twitch.tv/gql', $payload);
}

sub playStream {
    my ($client, $channel, $image, $title) = @_;

    my $clientId = 'kimne78kx3ncx6brgo4mv6wki5h1ko';
    my $oauth    = $prefs->get('oauth_token') || '';

    my $token_req = encode_json({
        operationName => 'PlaybackAccessToken_Template',
        variables     => {
            login      => $channel,
            playerType => 'embed',
        },
        query => 'query PlaybackAccessToken_Template($login: String!, $playerType: String!) {
            streamPlaybackAccessToken(channelName: $login, params: {
                platform: "web", playerBackend: "mediaplayer", playerType: $playerType
            }) {
                signature
                value
            }
        }',
    });

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;
            my $data = eval { decode_json($json) };
            return unless $data;

            my $sig = $data->{data}->{streamPlaybackAccessToken}->{signature};
            my $tok = $data->{data}->{streamPlaybackAccessToken}->{value};

            my $m3u8 = "https://usher.ttvnw.net/api/channel/hls/${channel}.m3u8?sig=${sig}&token=${tok}&allow_audio_only=true";

            my $m3u8_http = Slim::Networking::SimpleAsyncHTTP->new(
                sub {
                    my $body = shift;
                    my ($audio_url) = $body =~ /(https.*audio_only.*\.m3u8)/;
                    return unless $audio_url;

                    $client->playingSong->pluginData(wmaMeta => {
                        icon   => $image,
                        cover  => $image,
                        artist => $channel,
                        title  => $title || 'Live Twitch Stream',
                    });

                    Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
                    Slim::Control::Request::executeRequest($client, ['playlist', 'play', $audio_url]);
                },
                sub {
                    $log->warn("Fehler beim Laden des M3U8: $_[0]");
                },
                { timeout => 10 }
            );

            $m3u8_http->get($m3u8);
        },
        sub {
            $log->warn("Fehler beim Abrufen des Tokens: $_[0]");
        },
        { timeout => 10 }
    );

    $http->headers({
        'User-Agent'    => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        'Accept'        => '*/*',
        'Origin'        => 'https://www.twitch.tv',
        'Referer'       => 'https://www.twitch.tv/',
        'Content-Type'  => 'application/json',
        'Client-ID'     => $clientId,
        'Authorization' => "OAuth $oauth",
    });

    $http->post('https://gql.twitch.tv/gql', $token_req);
}

1;
