sub searchTwitch {
    my ($client, $query, $callback) = @_;

    my $clientId = 'kimne78kx3ncx6brgo4mv6wki5h1ko';
    my $oauth    = $prefs->get('oauth_token') || '';

    my $payload = encode_json([{
        operationName => 'SearchResultsPage_SearchResults',
        variables => {
            query => $query,
            options => {
                type  => 'CHANNEL',
                first => 10,
            }
        },
        extensions => {
            persistedQuery => {
                version     => 1,
                sha256Hash  => '8b3c96d2f4fd1a2aa7a2c3fc46a3a86b2f6d58c9efcb21f75d87ee6e85f1e4ba',
            }
        }
    }]);

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;

            my $data = eval { decode_json($json) };
            if ($@ || !$data || ref($data) ne 'ARRAY' || !$data->[0]{data}) {
                $log->warn("Ungültige JSON-Antwort von Twitch. JSON: $json");
                return $callback->([{
                    name => "Fehlerhafte Antwort von Twitch",
                    type => 'text',
                }]);
            }

            my $edges = $data->[0]{data}{search}{edges};
            unless ($edges && ref($edges) eq 'ARRAY') {
                $log->warn("Keine Suchergebnisse erhalten. Antwort: $json");
                return $callback->([{
                    name => "Keine Kanäle gefunden",
                    type => 'text',
                }]);
            }

            my @items;
            foreach my $edge (@$edges) {
                my $item = $edge->{item};
                next unless $item->{__typename} eq 'Channel';

                my $login     = $item->{login};
                my $title     = $item->{displayName};
                my $image     = $item->{profileImageURL};
                my $isLive    = $item->{isLive};
                my $streamTitle = $isLive ? ($item->{broadcastSettings}->{title} || 'Live Stream') : '';

                push @items, {
                    name => $title . ($isLive ? " - $streamTitle" : ''),
                    icon => $image,
                    type => 'link',
                    url  => "play:twitch:$login",
                };
            }

            $log->debug("Twitch-Suche erfolgreich: $query - " . scalar(@items) . " Einträge");
            $callback->(\@items);
        },
        sub {
            my ($http, $error) = @_;
            my $response = $http->response();
            my $status   = $response->code;
            my $msg      = $response->message;
            my $content  = $http->content;

            $log->warn("Fehler bei Twitch-Suche:");
            $log->warn("Statuscode: $status");
            $log->warn("Fehlermeldung: $msg");
            $log->warn("Antwortinhalt: $content");
            $log->warn("Suchbegriff: $query");

            $callback->([{
                name => "Fehler beim Abrufen von Twitch-Daten (HTTP $status)",
                type => 'text',
            }]);
        },
        { timeout => 10 }
    );

    $http->headers({
        'User-Agent'    => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        'Accept'        => '*/*',
        'Origin'        => 'https://www.twitch.tv',
        'Referer'       => 'https://www.twitch.tv/',
        'Content-Type'  => 'application/json',
        'Client-ID'     => $clientId,
        'Authorization' => "OAuth $oauth",
    });

    $http->post('https://gql.twitch.tv/gql', $payload);
}
