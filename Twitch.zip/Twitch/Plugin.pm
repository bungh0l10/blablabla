package Plugins::Twitch::Plugin;

use strict;
use base qw(Slim::Plugin::OPMLBased);

use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Control::Request;

use JSON::XS::VersionOneAndTwo qw(encode_json decode_json);

my $log = Slim::Utils::Log->addLogCategory({
    category     => 'plugin.twitch',
    defaultLevel => 'DEBUG',
    description  => 'PLUGIN_TWITCH',
});

my $prefs = preferences('plugin.twitch');

my $clientId = 'kimne78kx3ncx6brgo4mv6wki5h1ko';

sub initPlugin {
    my ($class, $client) = @_;

    $class->SUPER::initPlugin(
        feed    => \&searchChannels,
        tag     => 'twitch',
        menu    => 'radios',
        is_app  => 1,
        weight  => 1,
    );

    if (main::WEBUI) {
        require Plugins::Twitch::Settings;
        Plugins::Twitch::Settings->new();
    }

    $log->debug("Twitch Plugin with Search initialized.");
}

sub getDisplayName {
    return 'PLUGIN_TWITCH';
}

# Sucht Channels nach Begriff (z.B. in $prefs 'search_term' oder fest)
sub searchChannels {
    my ($client, $callback) = @_;

    my $search_term = $prefs->get('search_term') || 'sgqfmfunk';  # z.B. Standard-Suche

    # Twitch GraphQL Query um User-Daten zu bekommen
    my $query = {
        query => q{
            query($login: String!) {
                user(login: $login) {
                    login
                    displayName: login
                    profileImageURL: profileImageURL(width: 300)
                    stream {
                        id
                        title
                        viewersCount
                    }
                }
            }
        },
        variables => { login => $search_term },
    };

    my $json_query = encode_json($query);

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;
            my $data = eval { decode_json($json) };
            unless ($data && $data->{data} && $data->{data}->{user}) {
                $log->warn("Twitch Search returned no user");
                $callback->([]);
                return;
            }

            my $user = $data->{data}->{user};

            my @items = ({
                name  => $user->{displayName} || $user->{login},
                type  => 'link',
                url   => sub {
                    my ($client, $cb) = @_;
                    playStream($client, $user->{login}, $user->{profileImageURL}, $user->{stream}->{title} || 'Live Twitch Stream');
                },
                icon  => $user->{profileImageURL},
            });

            $callback->(\@items);
        },
        sub {
            $log->warn("Twitch Search HTTP error: $_[0]");
            $callback->([]);
        }
    );

    $http->headers({
        'Client-ID'    => $clientId,
        'Content-Type' => 'application/json',
        'User-Agent'   => 'Mozilla/5.0',
        'Accept'       => '*/*',
        'Origin'       => 'https://www.twitch.tv',
        'Referer'      => 'https://www.twitch.tv/',
    });

    $http->post('https://gql.twitch.tv/gql', $json_query);
}

sub playStream {
    my ($client, $channel, $icon_url, $title) = @_;

    return unless $client && $channel;

    my $token_req = {
        operationName => 'PlaybackAccessToken_Template',
        variables     => {
            login      => $channel,
            playerType => 'embed',
        },
        query => q{
            query PlaybackAccessToken_Template($login: String!, $playerType: String!) {
                streamPlaybackAccessToken(channelName: $login, params: { platform: "web", playerBackend: "mediaplayer", playerType: $playerType }) {
                    signature
                    value
                }
            }
        },
    };

    my $token_json = encode_json($token_req);

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $json = shift;
            my $data = eval { decode_json($json) };
            unless ($data && $data->{data} && $data->{data}->{streamPlaybackAccessToken}) {
                $log->warn("Failed to get Twitch playback token");
                return;
            }

            my $sig = $data->{data}->{streamPlaybackAccessToken}->{signature};
            my $tok = $data->{data}->{streamPlaybackAccessToken}->{value};

            my $m3u8 = "https://usher.ttvnw.net/api/channel/hls/${channel}.m3u8?sig=${sig}&token=${tok}&allow_audio_only=true";

            my $m3u8_http = Slim::Networking::SimpleAsyncHTTP->new(
                sub {
                    my $body = shift;
                    my ($audio_url) = $body =~ /(https.*audio_only.*\.m3u8)/;

                    unless ($audio_url) {
                        $log->warn("Audio only stream URL not found in M3U8");
                        return;
                    }

                    $client->playingSong->pluginData(wmaMeta => {
                        icon   => $icon_url,
                        cover  => $icon_url,
                        artist => $channel,
                        title  => $title,
                    });

                    Slim::Control::Request::notifyFromArray($client, ['newmetadata']);
                    Slim::Control::Request::executeRequest($client, ['playlist', 'play', $audio_url]);
                },
                sub { $log->warn("Failed to fetch M3U8: $_[0]") }
            );

            $m3u8_http->get($m3u8);
        },
        sub { $log->warn("Failed to get Twitch token: $_[0]") }
    );

    $http->headers({
        'Client-ID'    => $clientId,
        'Content-Type' => 'application/json',
        'User-Agent'   => 'Mozilla/5.0',
    });

    $http->post('https://gql.twitch.tv/gql', $token_json);
}

1;
